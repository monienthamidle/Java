//assignment 7 password 


import java.util.Scanner;

public class Password {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); 

		// Prompt the user to enter a password
		System.out.print("Enter a password: ");
		String s = input.nextLine();

		// Display Valid Password at least 8 characters, only letters & digits, contain at least 2 digits
		if (isValidPassword(s)) {
      		System.out.println("Valid Password");
	}
		else {
			System.out.println("Invalid Password");
		}
	}	
	
// checking method isValidPassword//
public static boolean isValidPassword(String s) {
    // Only letters and digits?
    for (int i = 0; i < s.length(); i++) {
      if (!Character.isLetter(s.charAt(i)) && 
          !Character.isDigit(s.charAt(i)))
        return false;
    }
    
    // length greater than 8
    if (s.length() < 8)
      return false;
    
    // Count the number of digits
    int count = 0;
    for (int i = 0; i < s.length(); i++) {
      if (Character.isDigit(s.charAt(i)))
        count++;
    }
    
    if (count >= 2)
      return true;
    else 
      return false;
  }
}